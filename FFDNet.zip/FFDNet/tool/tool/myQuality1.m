function [psnr, ssim] = myQuality1(x, y)

psnr = myPSNR1(x,y);
ssim = mySSIM1(x,y);


